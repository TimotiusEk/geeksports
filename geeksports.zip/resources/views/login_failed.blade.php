<html>
<head>
    <title>Login Failed</title>
</head>

<div style="width: 90%; margin-left: 5%; margin-right: 5%; margin-top:2%;background-color: #D1EED9; color: #930027; padding: 1%;">
    <b>Login failed. Please try again!</b>
</div>
</html>