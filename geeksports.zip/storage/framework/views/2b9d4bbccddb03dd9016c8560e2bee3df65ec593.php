<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/participant_registration.blade.php */ ?>
<html lang="en">
<head>
    <title>Event Registration</title>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet"/>
    <script>
        function validateForm() {
            var x = document.forms["registration_form"]["game"].value;
            if (x == -1) {
                alert("Game has not selected")

                return false;
            }
        }
    </script>
</head>
<body>

<div class="container">
    <h2>Event Registration</h2>
    <br/>
    <form name="registration_form" action="register_for_event" method="post" onsubmit="return validateForm()">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <b><label>Team Name</label></b><br>
            <input type="text" name="team_name" class="form-control" placeholder="Type here..."/>
        </div>
        <div class="form-group">
            <b><label>Participants</label></b><br>
            <select class="cari form-control" name="participants[]" multiple="multiple" id="mySelect2">
                <option value="2" selected><a href="#" class="detail-link">Carrera</a></option>
            </select>
        </div>

        <div class="form-group">
            <b><label>Games</label></b><br>
            <select class="form-control" name="game_id">
                <option disabled selected value=-1>Choose your game</option>
                <option value=1>Mobile Legends</option>
                <option value=2>Arena of Valor</option>
                <option value=3>Pro Evolution Soccer 2019</option>
            </select>
        </div>

        <input type="hidden" name="event_id" value="1"/>

        <div class="form-group">
            <button type="submit" class="form-control btn btn-primary"><b>Register</b></button>
        </div>
    </form>
</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $('.cari').select2({
        // tags: true,
        placeholder: 'Type Display Name',
        minimumInputLength: 3,
        ajax: {
            url: '/search_player',
            dataType: 'json',
            delay: 250,
            processResults: function (data) {
                return {
                    results: $.map(data, function (item) {
                        return {
                            text: item.display_name,
                            id: item.id
                        }
                    })
                };
            },
            cache: true
        }
    });
</script>


</body>
</html>