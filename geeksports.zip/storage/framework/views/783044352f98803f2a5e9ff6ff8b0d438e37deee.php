<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/home.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        document.getElementById("home").className = 'active';

        $(document).ready(function () {
            $("#common").attr("disabled", "disabled");
        });
    </script>


    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet"/>
</head>
<body style="background-color: whitesmoke">


<div class="container"
     style="width: 90%;">
    <div class="row" align="right">
        <button type="submit" class="form-control btn btn-primary"
                style="padding-left: 70px; padding-right: 70px; width: fit-content;"
                id="filter_btn" data-toggle="modal" data-target="#myModal"><b>Filter</b></button>
    </div>
    <?php if(count($events) != 0): ?>
        <?php for($idx = 0 ; $idx < count($events) ; $idx++): ?>

            <div class="row" style="background-color: white; margin-top: 2%; border-radius: 10px;">
                <div class="col-md-5 text-center">
                    <img style=" height: 225px; width: 400px; margin-top: 23px;"
                         src="/images/event_brochure/<?php echo e(($events[$idx])->brochure); ?>"/>
                </div>
                <div class="col-md-7" style="font-size: 40px; vertical-align: top;">
                    <div style="margin-left: 70px">
                        <p style="margin-top: 20px; margin-left: -30px;"><b><a
                                        href="/event_details?event_id=<?php echo e(($events[$idx])->id); ?>"
                                        style="color: black"><?php echo e(($events[$idx])->name); ?></a></b>
                        </p>
                        <p style="font-size: 18px; margin-top: -10px; margin-left: -23px;">By: <a
                                    href="/view_profile?user_id=<?php echo e(($events[$idx]->event_organizer)->user_idnote); ?>"><?php echo e(($events[$idx]->event_organizer)->display_name); ?></a>
                        </p>
                        <hr>
                        <div style="font-size: 23px; margin-top: -10px"><img src="images/ic_location.png"
                                                                             style="width: 30px; margin-right: 10px; margin-bottom: 10px;"> <?php if($city_name[$idx] != null): ?><?php echo e($city_name[$idx]); ?> <?php else: ?>
                                - <?php endif; ?>
                        </div>
                        <div style="font-size: 23px; margin-bottom: 10px"><img src="images/ic_datetime.png"
                                                                               style="width: 30px; margin-right: 10px; margin-top: -5px"><?php if($events[$idx]->start_date != null): ?> <?php echo e(($events[$idx])->start_date); ?>

                            - <?php echo e(($events[$idx])->end_date); ?> <?php else: ?> - <?php endif; ?>
                        </div>
                        <div style="font-size: 23px; "><img src="images/ic_game.png"
                                                            style="width: 30px; margin-right: 10px; margin-top: -5px">
                            <?php if(($games[$idx]) != null): ?><?php echo e($games[$idx]); ?> <?php else: ?> - <?php endif; ?>
                            <form action="event_details" method="GET">
                                <input type="hidden" value="<?php echo e(($events[$idx])->id); ?>" name="event_id"/>
                                <a href="#" onclick="$(this).closest('form').submit()"><img
                                            src="/images/details_btn.png" width="125px" align="right"
                                            style="margin-bottom: 10px"/></a>
                            </form>
                        </div>

                    </div>
                </div>
            </div>

        <?php endfor; ?>
    <?php endif; ?>
</div>
<!-- MODAL -->
<div class="Event Filter">
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-xl">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Filter Event</h4>
                </div>
                <form action="home">
                    <div class="modal-body">
                        <div class="form-group">
                            <p style="font-size: 18px"><b>Games</b></p>
                            <select class="cari form-control" name="game_id[]" multiple="multiple" id="mySelect2"
                                    style="width: 100%">
                                <?php if($filter != "true"): ?>
                                    <?php $__currentLoopData = $user_games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user_game->game_id); ?>" selected><?php echo e($user_game->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <p style="font-size: 18px"><b>City</b></p>
                            <select class="city form-control" name="city_id[]" id="mySelect2"
                                    style="width: 100%" multiple="multiple"></select>
                        </div>

                        <input type="text" class="form-control" placeholder="Event keyword (Optional)"
                               name="keyword" style="margin-top: 40px">
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-default" name="filter" value="true">Filter</button>
                        </div>
                </form>
            </div>

        </div>
    </div>
</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $('.cari').select2({
        placeholder: 'Type here...',
        ajax: {
            url: '/search_game',
            dataType: 'json',
            delay: 250,
            processResults: function (data) {
                return {
                    results: $.map(data, function (item) {
                        return {
                            text: item.name,
                            id: item.id
                        }
                    })
                };
            },
            cache: true
        }
    });

    $('.city').select2({
        placeholder: 'Type here...',
        ajax: {
            url: '/search_city',
            dataType: 'json',
            delay: 250,
            processResults: function (data) {
                return {
                    results: $.map(data, function (item) {
                        return {
                            text: item.name,
                            id: item.id
                        }
                    })
                };
            },
            cache: true
        }
    });
</script>
</body>
</html>