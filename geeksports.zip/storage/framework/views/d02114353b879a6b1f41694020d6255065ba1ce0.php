<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/broadcast_package.blade.php */ ?>
<html>

<body>



<form action="sponsor_search_result" method="post" name="myForm" id="myForm">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
    <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>

    <?php if(is_array($industry_id)): ?>
        <?php if(count($industry_id) != 0): ?>
            <?php for($idx = 0 ; $idx < count($industry_id) ; $idx++): ?>
                <input type="hidden" name="industry_id[]" value="<?php echo e($industry_id[$idx]); ?>"/>
            <?php endfor; ?>
        <?php endif; ?>
    <?php endif; ?>

    <?php if($keyword != ""): ?>
        <input type="hidden" name="keyword" value="<?php echo e($keyword); ?>"/>
    <?php endif; ?>
</form>

<script type="text/javascript">
    function submitForm() {
        document.forms["myForm"].submit();
    }

    submitForm();
</script>
</body>
</html>