<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/manage_event_2.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" type="text/css" id="common" href="/css/vertical_menu.css"/>
        
    <script>
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("demo").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "manage_participant?event_id=2", true);
        xhttp.send();
    </script>
</head>

<body style="background-color: whitesmoke">
<div class="container"
     style="border-radius: 10px; border-color: #491217; width: 98%; margin: 1%">
    <div class="row" style="background-color: white">
        <div class="col-md-4 text-center">
            <img style=" height: 225px; width: 400px; border-radius: 10px; margin-top: 8px;"
                 src="/images/event_brochure/brochure_1.jpg"/>
        </div>
        <div class="col-md-8" style="font-size: 40px; vertical-align: top;">
            <div style="margin-left: 70px">
                <p style="margin-top: 20px; margin-left: -30px;">
                    <b>
                        
                        
                        The International 2019
                        
                    </b>
                </p>
                <hr>
                <div style="font-size: 23px; margin-top: -10px"><img src="images/ic_location.png"
                                                                     style="width: 30px; margin-right: 10px; margin-bottom: 10px;">
                    
                    
                    Tangerang
                </div>
                <div style="font-size: 23px; margin-bottom: 10px"><img src="images/ic_datetime.png"
                                                                       style="width: 30px; margin-right: 10px; margin-top: -5px">
                    
                    
                    21 June - 23 June 2019
                </div>
                <div style="font-size: 23px; "><img src="images/ic_game.png"
                                                    style="width: 30px; margin-right: 10px; margin-top: -5px">
                    
                    Dota 2
                    
                    
                    
                    
                    
                    
                </div>

            </div>
        </div>
    </div>

    <div class="row" style="background-color: white; margin-top: 20px" align="center">
        <div class="col-md-2">
            <div class="vertical-menu" style="margin: 1%; width: 98%">
                <a href="#" class="active" id="participant">Participants</a>
                <a href="#">Vacancy</a>
                <a href="#">News</a>
                <a href="#">Sponsorship Package</a>
                <a href="#">Streaming Channels</a>
            </div>
        </div>
        <div class="col-md-10" id="demo">
        </div>
    </div>
</div>

<script>

    clickedTab("Register");

    function clickedTab(id) {
        $(".active").removeClass("active");
        $("#" + id).addClass("active");
        $("#participant").addClass("active");


        $(".participant_list").hide();
        $("#" + id + "_participants").show();

    }


</script>



    
        
        
            
            
            
            
                
                    
                        
                            
                            
                        
                    
                
            
            
        
    

</body>
</html>