<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/register_eo.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <script>
        $(function () {
            $("#sponsor").on('change', function (e) {
                if ($(this).is(':checked')) {
                    $("#visible-for-sponsor-and-eo").show();
                    $("#industry").show();
                } else {
                    if (!$("#event_organizer").is(':checked')) {
                        $("#visible-for-sponsor-and-eo").hide();
                    }
                    $("#industry").hide();
                }
            });

            $("#event_organizer").on('change', function (e) {
                if (!$("#sponsor").is(':checked')) {
                    if ($(this).is(':checked')) {
                        $("#visible-for-sponsor-and-eo").show();
                    } else {
                        $("#visible-for-sponsor-and-eo").hide();

                        if (!$("#sponsor").is(':checked')) {
                            $("#industry").hide();
                        }
                    }
                }
            });
        });
    </script>
</head>
<body>

<form action="register_step_">
    <div class="text-center"><img src="/images/logo.png" class="logo"></div>
    <div class="text-center"><img src="/images/account_step_signup_2.png" class="steps"></div>

    <div class="form-group">
        <b><label>Fullname</label></b>
        <div class="inner-addon left-addon">
            <i class="glyphicon glyphicon-user"></i>
            <input type="password" class="form-control" placeholder="Type here..."/>
        </div>
    </div>
    <div class="form-group">
        <b><label>Date of Birth</label></b>
        <div class="inner-addon left-addon">
            <i class="glyphicon glyphicon-calendar"></i>
            <input type="date" class="form-control" placeholder="Pick Date"/>
        </div>
    </div>
    <div class="form-group">
        <b><label>Address</label></b>
        <textarea class="form-control" rows="5" id="address" placeholder="Type here..."></textarea>
    </div>
    <div class="form-group">
        <b><label>Roles in E-Sports Community</label></b><br>
        <div class="container-fluid">
            <div class="row" style="margin-bottom: 0.5%">
                <div class="col-sm-4"><input type="checkbox" value=""> Commentator</div>
                <div class="col-sm-4"><input type="checkbox" value=""> E-Sport Athlete</div>
                <div class="col-sm-4"><input type="checkbox" value=""> Location Provider</div>
            </div>
            <div class="row" style="margin-bottom: 0.5%">
                <div class="col-sm-4"><input id="sponsor" type="checkbox" value=""> Sponsor</div>
                <div class="col-sm-4"><input id="event_organizer" type="checkbox" value=""> Event Organizer</div>
                <div class="col-sm-4"><input type="checkbox" value=""> E-Sport Enthusiast</div>
            </div>
        </div>
    </div>
    <div id="visible-for-sponsor-and-eo" hidden>
        <div class="form-group">
            <b><label>Company Name</label></b>
            <input type="text" class="form-control" placeholder="Type here..."/>
        </div>

        <div class="form-group" id="industry" hidden>
            <b><label>Industry</label></b><br>

            <div class="container-fluid">
                <div class="row" style="margin-bottom: 0.5%">
                    <div class="col-sm-4"><input type="checkbox" value=""> Gaming Gear</div>
                    <div class="col-sm-4"><input type="checkbox" value=""> Food</div>
                    <div class="col-sm-4"><input type="checkbox" value=""> Drink</div>
                </div>
                <div class="row" style="margin-bottom: 0.5%">
                    <div class="col-sm-4"><input type="checkbox" value=""> Clothing</div>
                    <div class="col-sm-4"><input type="checkbox" value=""> Transportation Service</div>
                    <div class="col-sm-4"><input type="checkbox" value=""> Logistic</div>
                </div>
                <div class="row" style="margin-bottom: 0.5%">
                    <div class="col-sm-4"><input type="checkbox" value=""> Transportation Industry</div>
                    <div class="col-sm-4"><input type="checkbox" value=""> Medical</div>
                    <div class="col-sm-4"><input type="checkbox" value=""> Software</div>
                </div>
                <div class="row" style="margin-bottom: 0.5%">
                    <div class="col-sm-4"><input type="checkbox" value=""> Hardware</div>
                    <div class="col-sm-4"><input type="checkbox" value=""> Media</div>
                    <div class="col-sm-4"><input type="checkbox" value=""> Restaurant</div>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group has-feedback">
        <button type="submit" class="form-control btn btn-primary"><b>Next Step <span
                        class="glyphicon glyphicon-btn glyphicon-arrow-right form-control-feedback"></span></b></button>
    </div>
</form>
</body>
</html>


