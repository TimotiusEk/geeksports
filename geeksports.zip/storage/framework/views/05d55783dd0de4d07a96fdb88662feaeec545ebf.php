<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/register_done.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
</head>
<body>
    <div class="text-center"><img src="/images/logo.png" class="logo"></div>
    <div class="text-center"><img src="/images/account_step_signup_3.png" class="steps"></div>
    <div class="text-center"><img src="/images/smiley_done.png" class="steps"></div>
    <div class="text-center"> <button onclick="location.href = '/';" class="btn btn-primary" style="width: 97%; margin-top: 3%"><b>Login</b></button></div>
</body>
</html>