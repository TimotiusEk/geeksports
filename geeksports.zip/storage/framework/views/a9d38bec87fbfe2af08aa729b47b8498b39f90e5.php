<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/change_vacancy_status.blade.php */ ?>
<html>

<body>

<form action="manage_vacancy" method="post" name="myForm" id="myForm">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
</form>

<script type="text/javascript">
    function submitForm() {
        document.forms["myForm"].submit();
    }

    submitForm();
</script>
</body>
</html>