<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/view_profile_event_organizer.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        td {
            padding-left: 100px;
            text-align: center;
        }
    </style>

    <script>
        document.getElementById("profile").className = 'active';
    </script>
</head>
<body style="background-color: whitesmoke">
<div class="container" style="width: 98%; padding: 1%; margin: 1%">
    <div class="row" align="center" style="background-color: white; border-radius: 10px;">
        <img src="/images/profile_picture/<?php echo e($user->profile_picture); ?>" width="150px" height="150px" class="img-circle"
             style="margin-top: 20px"/>
        <p style="font-size: 50px"><?php echo e($user->display_name); ?> <?php if($edit == true): ?><a
                    href="update_profile?user_id=<?php echo e($user->user_id); ?>"><img src="/images/ic_edit_no_text.png"
                                                                          width="25px"/></a><?php endif; ?></p>
        <p style="font-size: 25px; margin-top: -15px; margin-bottom: 45px"><?php echo e($user->company_name); ?></p>
        <div style="background-color: #f4f4f4; font-size: 23px; padding: 2%; margin: 1%">
            <pre style="font-size: 23px; border-width: 0px; font-family: 'Arial';"
                 align="left"><?php echo e($user->contact_person); ?></pre>
        </div>
    </div>


    <div class="row" style="background-color: white; border-radius: 10px; margin-top: 30px; padding: 1%">
        <p style="margin-top: 20px; margin-left: 10px; font-size: 40px;"><b>Managed Event</b></p>
        <hr>
        <?php $__currentLoopData = $user->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="event_details?event_id=<?php echo e($user_event->id); ?>" style="color: black">
                <div class="col-md-3" align="center" style="margin-bottom: 20px">
                    <img src="/images/event_brochure/<?php echo e($user_event->brochure); ?>"
                         style="max-width: 200px; max-height: 100px"/>
                    <p style="font-size: 23px; margin-top: 10px; margin-bottom: -5px"><b><?php echo e($user_event->name); ?></b></p>
                    <p style="margin-top: 5px"><b style="font-size: 18px"><?php echo e($user_event->rating); ?></b> <img
                                src="/images/star_grey.png" width="15px" height="15px" style="margin-top: -6px"/>
                        (<?php echo e($user_event->no_of_user_rate); ?>)</p>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


</div>
</body>
</html>