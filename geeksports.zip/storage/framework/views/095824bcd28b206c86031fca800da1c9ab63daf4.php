<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/signin.blade.php */ ?>
<html>
<head>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
            crossorigin="anonymous"></script>
    <script src="/js/bootstrap.js"></script>

    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/css/common.css"/>
</head>
<body>
<form>
    <div class="text-center"><img src="/images/logo.png" class="logo"></div>
    
    <div class="form-group">
        <b><label for="exampleInputEmail1">Username</label></b>

        <div class="inner-addon left-addon">
            <i class="glyphicon glyphicon-user"><img src="/images/ic_person.png"></i>
            <input type="text" class="form-control" placeholder="Type here..."/>
        </div>
    </div>
    <div class="form-group">
        <b><label for="exampleInputPassword1">Password</label></b>
        <div class="inner-addon left-addon">
            <i class="glyphicon glyphicon-user"><img src="/images/ic_lock.png"></i>
            <input type="password" class="form-control" placeholder="Type here..."/>
        </div>
    </div>
    <div class="form-group">
       <div class="text-right">Don't have account? <a href="#">Register here!</a></div>
    </div>
    <button type="submit" class="btn btn-primary"><b>LOGIN</b></button>
</form>

</body>
</html>