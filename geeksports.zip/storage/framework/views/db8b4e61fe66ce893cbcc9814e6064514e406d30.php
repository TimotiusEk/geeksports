<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/update_streaming_channel.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php include 'php/datatables.php'; ?>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap-clockpicker.min.css">
    <script>
        $("#dashboard_nav_bar").show();

        document.getElementById("dashboard").className = 'active';
    </script>
</head>
<body>
<h1 style="margin-left: 1%; font-size: 35px"><b>Update Streaming Channel</b></h1>
<hr style="height:1px;border:none;color:#333;background-color:#333; width: 99%">

<h2 style="margin-left: 1%; font-size: 30px">The International 2019 ( - )</h2>

<?php if(isset($success)): ?>
    <?php if($success == true): ?>
        <div style="width: 48%; margin-left: 26%; margin-right: 26%; margin-top:2%;background-color: #D1EED9; color: #930027; padding: 1%;">
            <b>Streaming Channel has been updated successfully!</b>
        </div>

        <form method="get" action="manage_streaming_channel" name="myForm" id="myForm">
            <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
        </form>
    <?php endif; ?>
<?php endif; ?>

<form action="update_streaming_channel" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <b><label>Title</label></b>
        <input type="text" class="form-control" name="title" value="<?php echo e($streaming_channel->title); ?>" required/>
    </div>

    <div class="form-group">
        <b><label>URL</label></b>
        <input type="text" class="form-control" name="url" value="<?php echo e($streaming_channel->url); ?>" required/>
    </div>

    <div class="form-group">
        <b><label>Start Date (Optional)</label></b>
        <div class="inner-addon left-addon">
            <i class="glyphicon glyphicon-calendar"></i>
            <input type="date" class="form-control" name="start_date" value="<?php echo e($streaming_channel->start_date); ?>"/>
        </div>
    </div>

    <div class="form-group clockpicker">
        <b><label>Start Time (Optional)</label></b>
        <div class="inner-addon left-addon">
            <i class="glyphicon glyphicon-time"></i>
            <input type="text" class="form-control" name="start_time"
                   <?php if($streaming_channel->start_time != null): ?> value="<?php echo e($streaming_channel->start_time); ?>" <?php endif; ?>/>
        </div>
    </div>

    <!--todo: set event id by previous page-->
    <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
    <input type="hidden" name="streaming_channel_id" value="<?php echo e($streaming_channel->id); ?>"/>

    <button type="submit" class="form-control btn btn-primary" style="margin-top: 35px"><b>Update Streaming Channel</b>
    </button>
</form>

<?php if(isset($success)): ?>
    <?php if($success == true): ?>
        <script type="text/javascript">
            function submitform() {
                document.forms["myForm"].submit();
            }

            setTimeout(submitform, 2000)
        </script>
    <?php endif; ?>
<?php endif; ?>

<script type="text/javascript" src="/js/bootstrap-clockpicker.min.js"></script>
<script type="text/javascript">
    $('.clockpicker').clockpicker({
        donetext: 'Done'
    });
</script>
</body>
</html>