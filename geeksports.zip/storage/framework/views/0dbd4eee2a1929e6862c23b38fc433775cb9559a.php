<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/company_profile.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        document.getElementById("profile").className = 'active';
    </script>
</head>
<body>

</body>
</html>