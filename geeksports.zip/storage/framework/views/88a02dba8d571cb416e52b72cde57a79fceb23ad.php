<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/manage_vacancy.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    @include('nav_header')
    <?php include 'php/datatables.php'; ?>
    <script>
        $("#dashboard_nav_bar").show();
        document.getElementById("manage_event").className = 'active';
        document.getElementById("dashboard").className = 'active';

        $(document).ready(function () {
            $("#common").attr("disabled", "disabled");
        });
    </script>
</head>
<body>
<!--todo: add event id-->
<h1 style="margin-left: 1%; font-size: 50px"><b>Roles Vacancy</b></h1>
<hr style="height:1px;border:none;color:#333;background-color:#333; width: 99%">
<h2 style="margin-left: 1%; font-size: 40px">Moba Community Tangerang Cup (17 September 2019 - 19 September 2019)</h2>
<h1 align="center" style="margin-top: 15%" id="no_news"><b>There is no Roles Vacancy for This Event</b></h1>
<a href="/write_news"><img src="/images/ic_add_vacancy.png" style="width: 200px; margin-right: 1.5%; position:absolute; right:0; margin-top: 10%;" id="write_news"></a>
</body>
</html>
