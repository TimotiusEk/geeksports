<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/invite_worker.blade.php */ ?>
<html>

<body>



<form action="worker_search_result" method="post" name="myForm" id="myForm">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
    <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>

    <?php if(is_array($subrole_id)): ?>
        <?php if(count($subrole_id) != 0): ?>
            <?php for($idx = 0 ; $idx < count($subrole_id) ; $idx++): ?>
                <input type="hidden" name="subrole_id[]" value="<?php echo e($subrole_id[$idx]); ?>"/>
            <?php endfor; ?>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(is_array($game_id)): ?>
        <?php if(count($game_id) != 0): ?>
            <?php for($idx = 0 ; $idx < count($game_id) ; $idx++): ?>
                <input type="hidden" name="game_id[]" value="<?php echo e($game_id[$idx]); ?>"/>
            <?php endfor; ?>
        <?php endif; ?>
    <?php endif; ?>

    <?php if($keyword != ""): ?>
        <input type="hidden" name="keyword" value="<?php echo e($keyword); ?>"/>
    <?php endif; ?>
</form>

<script type="text/javascript">
    function submitForm() {
        document.forms["myForm"].submit();
    }

    submitForm();
</script>
</body>
</html>