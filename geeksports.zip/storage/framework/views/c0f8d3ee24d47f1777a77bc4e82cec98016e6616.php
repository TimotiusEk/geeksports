<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/worker_search_result.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php include 'php/datatables.php'; ?>
    <script>
        $("#dashboard_nav_bar").show();
        document.getElementById("manage_event").className = 'active';
        document.getElementById("dashboard").className = 'active';

        $(document).ready(function () {
            $("#common").attr("disabled", "disabled");
        });
    </script>
</head>
<body>
<!--todo: add event id-->
<h1 style="margin-left: 1%; font-size: 35px"><b>Search Result (People)</b></h1>
<hr style="height:1px;border:none;color:#333;background-color:#333; width: 99%"/>
<h2 style="margin-left: 1%; font-size: 30px; margin-bottom: 25px"><?php echo e($event_information); ?></h2>
<h2 style="margin-left: 1%; font-size: 25px">Role <span
            style="margin-left: 38px">:</span> <?php if(count($subrole_name) != 0): ?> <?php for($idx = 0 ; $idx < count($subrole_name) ; $idx++): ?> <?php echo e($subrole_name[$idx]); ?> <?php if($idx != count($subrole_name) - 1): ?> <?php echo e(","); ?><?php endif; ?> <?php endfor; ?> <?php else: ?> <?php echo e("-"); ?> <?php endif; ?>
</h2>

<h2 style="margin-left: 1%; font-size: 25px">Game <span
            style="margin-left: 22px">:</span> <?php if(count($game_name) != 0): ?> <?php for($idx = 0 ; $idx < count($game_name) ; $idx++): ?> <?php echo e($game_name[$idx]); ?> <?php if($idx != count($game_name) - 1): ?> <?php echo e(","); ?><?php endif; ?> <?php endfor; ?> <?php else: ?> <?php echo e("-"); ?> <?php endif; ?>
</h2>
<h2 style="margin-left: 1%; font-size: 25px">Keyword: <?php if($keyword != ""): ?><?php echo e($keyword); ?> <?php else: ?><?php echo e("-"); ?><?php endif; ?></h2>
<hr style="height:0.5px;border:none;color:#333;background-color:#333; width: 99%"/>

<!--check if all search result has been invited-->
<?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($s == null): ?>
        <form action="invite_people" method="post">
            <?php echo e(csrf_field()); ?>

            <div align="right" style="margin-right: 20px">
                <?php for($user_idx = 0 ; $user_idx < count($user_id); $user_idx++): ?>
                    <?php if($status[$user_idx] == null): ?>
                        <input type="hidden" name="user_id[]" value="<?php echo e($user_id[$user_idx]); ?>"/>
                    <?php endif; ?>
                <?php endfor; ?>
                <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
                <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>

                <?php if(is_array($subrole_id) && count($subrole_id) != 0): ?>
                    <?php $__currentLoopData = $subrole_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="subrole_id[]"
                               value="<?php echo e($id); ?>"/>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(is_array($game_id) && count($game_id) != 0): ?>
                    <?php $__currentLoopData = $game_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="game_id[]"
                               value="<?php echo e($id); ?>"/>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if($keyword != ""): ?>
                    <input type="hidden" name="keyword" value="<?php echo e($keyword); ?>"/>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary text-right" style="padding-left: 1%; padding-right: 1%;">
                    <b>Invite All</b></button>
            </div>
            <br>
        </form>
        <?php break; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<table style="margin-left: 1%; margin-right:1%;width: 98%">
    <tr>
        <td>
            <div class="container">
                <div class="row">

                    <?php for($idx = 0 ; $idx < count($display_names) ; $idx++): ?>
                        <div class="col-md-2"
                             style="background-color: #eaffea; border-radius: 5px; border: 1px outset #18253d;width: 561px; padding: 1%; margin: 1%;">
                            <div align="center">
                                <img src="/images/sample_profile_picture_1.jpg" width="100px" height="100px"
                                     class="img-circle"/>
                            </div>
                            <div align="center" style="font-size: 20px; margin-top: 10px;">
                                <b><?php echo e($display_names[$idx]); ?></b>
                            </div>
                            <div align="center" style="font-size: 20px; margin-top: 5px;">
                                <?php echo e($subroles[$idx]); ?>

                            </div>

                            <div align="center" style="font-size: 18px; margin-top: 5px;">
                                (<?php echo e($user_games[$idx]); ?>)
                            </div>
                            <div align="center" style="margin-top: 30px">
                                <form method="post" action="invite_people">
                                    <?php echo e(csrf_field()); ?>

                                    <?php if($status[$idx] == "Invite"): ?>
                                        <button class="form-control btn btn-dark" disabled><b>Invited</b>
                                        </button>

                                    <?php else: ?>
                                        <button class="form-control btn btn-primary"><b>Invite to Event</b>
                                        </button>
                                    <?php endif; ?>
                                    <input type="hidden" name="user_id" value="<?php echo e($user_id[$idx]); ?>"/>
                                    <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
                                    <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>

                                    <?php if(is_array($subrole_id) && count($subrole_id) != 0): ?>
                                        <?php $__currentLoopData = $subrole_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="subrole_id[]"
                                                   value="<?php echo e($id); ?>"/>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <?php if(is_array($game_id) && count($game_id) != 0): ?>
                                        <?php $__currentLoopData = $game_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="game_id[]"
                                                   value="<?php echo e($id); ?>"/>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <?php if($keyword != ""): ?>
                                        <input type="hidden" name="keyword" value="<?php echo e($keyword); ?>"/>
                                    <?php endif; ?>


                                </form>
                            </div>
                        </div>

                    <?php endfor; ?>
                </div>
            </div>
        </td>
    </tr>
</table>


</body>
</html>
