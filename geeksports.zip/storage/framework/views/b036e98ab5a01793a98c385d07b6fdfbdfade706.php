<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/add_vacancy.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php include 'php/datatables.php'; ?>
    <script>
        $("#dashboard_nav_bar").show();
        document.getElementById("manage_event").className = 'active';
        document.getElementById("dashboard").className = 'active';
    </script>


</head>
<body>

<h1 style="margin-left: 1%; font-size: 35px"><b>Add Vacancy</b></h1>
<hr style="height:1px;border:none;color:#333;background-color:#333; width: 99%">
<h2 style="margin-left: 1%; font-size: 30px; margin-bottom: 2%"><?php echo e($event_information); ?></h2>

<?php if(isset($success)): ?>
    <?php if($success == true): ?>
        <div style="width: 48%; margin-left: 26%; margin-right: 26%; margin-top:2%;background-color: #D1EED9; color: #930027; padding: 1%;">
            <b>Vacancy has been added successfully!</b>
        </div>

        <form method="post" action="manage_vacancy" name="myForm" id="myForm">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
            <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>
        </form>
    <?php endif; ?>
<?php endif; ?>


<form style="margin-left: 1%; font-size: 20px" action="add_vacancy" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <b><label>Vacant Roles</label></b><br>
        <div class="container-fluid">

            <?php $__currentLoopData = $subroles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subrole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4"><input type="checkbox"
                                             value=<?php echo e($subrole->id); ?> name="subrole_id[]"> <?php echo e($subrole->name); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <div class="form-group">
        <b><label>Description</label></b>
        <textarea class="form-control" rows="5" placeholder="Type here..." name="description"></textarea>
    </div>


    <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
    <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>

    <button type="submit" class="form-control btn btn-primary"><b>Add</b></button>
</form>

<?php if(isset($success)): ?>
    <?php if($success == true): ?>
        <script type="text/javascript">
            function submitform() {
                document.forms["myForm"].submit();
            }


            setTimeout(submitform, 2000)
        </script>
    <?php endif; ?>
<?php endif; ?>
</body>
</html>
