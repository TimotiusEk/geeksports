<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/update_package.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php include 'php/datatables.php'; ?>
    <script>
        $("#dashboard_nav_bar").show();
        document.getElementById("manage_event").className = 'active';
        document.getElementById("dashboard").className = 'active';
    </script>
</head>
<body>
<h1 style="margin-left: 1%; font-size: 35px"><b>Update Sponsorship Package</b></h1>
<hr style="height:1px;border:none;color:#333;background-color:#333; width: 99%">
<h2 style="margin-left: 1%; font-size: 30px"><?php echo e($event_information); ?></h2>

<?php if(isset($success)): ?>
    <?php if($success == true): ?>
        <div style="width: 48%; margin-left: 26%; margin-right: 26%; margin-top:2%;background-color: #D1EED9; color: #930027; padding: 1%;">
            <b>Package has been updated successfully!</b>
        </div>

        <form method="post" action="manage_sponsorship_package" name="myForm" id="myForm">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
            <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>
        </form>
    <?php endif; ?>
<?php endif; ?>

<form action="update_package" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <b><label>Package Name</label></b>
        <input type="text" class="form-control" placeholder="Type here..." name="package_name" value="<?php echo e($package->package_name); ?>"/>
    </div>

    <div class="form-group">
        <b><label>Sponsor Rights</label></b>
        <textarea class="form-control" rows="5" id="address" placeholder="Type here..." name="sponsor_rights"><?php echo e($package->sponsor_rights); ?></textarea>
    </div>

    <div class="form-group">
        <b><label>Sponsor Obligations</label></b>
        <textarea class="form-control" rows="5" id="address" placeholder="Type here..." name="sponsor_obligations"><?php echo e($package->sponsor_obligations); ?></textarea>
    </div>

    <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
    <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>
    <input type="hidden" name="package_id" value="<?php echo e($package->id); ?>"/>

    <button type="submit" class="form-control btn btn-primary" style="margin-top: 35px"><b>Update Package</b></button>
</form>

<?php if(isset($success)): ?>
    <?php if($success == true): ?>
        <script type="text/javascript">
            function submitform() {
                document.forms["myForm"].submit();
            }
            setTimeout(submitform, 2000)
        </script>
    <?php endif; ?>
<?php endif; ?>

</body>
</html>