<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/manage_news.blade.php */ ?>
<html>
<head>
    <?php include 'php/required_css.php'; ?>
    <?php include 'php/required_js.php'; ?>
    @include('nav_header')
    <?php include 'php/datatables.php'; ?>

    <script>
        document.getElementById("manage_event").className = 'active';
    </script>
</head>
<body>
<h1 style="margin-left: 1%; font-size: 35px"><b>Manage News</b></h1>
<hr style="height:1px;border:none;color:#333;background-color:#333; width: 99%">
<h2 style="margin-left: 1%; font-size: 30px">test 121 (15 April 2019 - 17 April 2019)</h2>

<h1 align="center" style="margin-top: 15%" id="no_news"><b>No News is Drafted or Published</b></h1>

<a href="/write_news"><img src="/images/ic_add_news.png"
                           style="width: 160px; margin-right: 1.5%; position:absolute; right:0; margin-top: 11%;"
                           id="write_news"></a>

<a href="/write_news" id="write_news_btn" style="display: none"><button type="submit" class="form-control btn btn-primary" style="width: fit-content; position: relative; left: 88%; margin-bottom: 30px; padding-left: 30px; padding-right: 30px;"><b>Write News</b></button></a>
<div id="datatable" style="display: none; margin-top: -40px">
    <table id="table_id" class="cell-border table-bordered" width="99%;" >
        <thead>
        <tr>
            <th>No</th>
            <th>Title</th>
            <th>Created At</th>
            <th>Last Modified</th>
            <th>Published On</th>
            <th>Status</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>1</td>
            <td>Micro SD 1 TB Jadi Sebuah Bahan Pembicaraan Pada MWC 2019</td>
            <td>20 January 2019 - 19:30</td>
            <td>23 January 2019 - 09:20</td>
            <td>-</td>
            <td>In Draft</td>
            <td>
                <img src="/images/ic_edit.png" style="width: 60px; height: 40px; margin-bottom: 10px;"/><br>
                <img src="/images/ic_delete.png" style="width: 65px; height: 45px; margin-bottom: 10px;"/><br>
                <img src="/images/ic_publish.png" style="width: 65px; height: 45px; margin-left: 3px"/>
            </td>
        </tr>
        <tr>
            <td>2</td>
            <td>Kisah Pak Pras Ubah Pandangan Negatif Esports di Sekolah</td>
            <td>2 March 2019 - 18:01</td>
            <td>3 March 2019 - 02:20</td>
            <td class="dt-body-center">5 March 2019 - 16:10</td>
            <td>Published</td>
            <td>
                <img src="/images/ic_delete.png" style="width: 65px; height: 45px; margin-top: 4px; margin-bottom: 10px;"/><br>
            </td>
        </tr>
        </tbody>
    </table>


</div>
<script>
    $(document).ready(function () {
        $('#table_id').DataTable({
            "bLengthChange": false,
            "dom": '<"pull-left"f><"pull-right"l>tip',
            "columnDefs": [ {
                "targets": -1,
                "orderable": false
            } ]
        });

        $("th").addClass("dt-head-center");
        $("td").addClass("dt-body-center");
    });

    $("#dashboard_nav_bar").show();
    document.getElementById("broadcast_news").className = 'active';
    document.getElementById("dashboard").className = 'active';

    <?php
    if(isset($_GET["is_empty"])){
    ?>
    $("#no_news").hide();
    $("#datatable").show();
    $("#write_news").hide();
    $("#write_news_btn").show();
    <?php
    }
    ?>
</script>

</body>
</html>