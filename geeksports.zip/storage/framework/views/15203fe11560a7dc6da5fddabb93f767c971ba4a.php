<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/create_event.blade.php */ ?>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/css/common.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="/home"><img src="/images/logo-no-slogan.png" width="90px" style="margin-top: -13px"></a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="/home">Home</a></li>
            <li><a href="/search">Search</a></li>
            <li class="active"><a href="/dashboard">Dashboard</a></li>
            <li><a href="/profile">Profile</a></li>
        </ul>
    </div>
</body>
<ul class="nav nav-pills nav-justified justify-content-center" style="margin-top: 1%" >
    <li class="active"><a href="#">Create Event</a></li>
    <li><a href="#">Broadcast News</a></li>
    <li><a href="#">Manage Event</a></li>
</ul>

</html>