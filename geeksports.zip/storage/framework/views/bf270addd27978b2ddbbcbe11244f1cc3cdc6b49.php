<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/publish_news.blade.php */ ?>
<html>

<body>

<form action="manage_news" method="post" name="myForm" id="myForm">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="event_id" value="<?php echo e($event_id); ?>"/>
    <input type="hidden" name="event_information" value="<?php echo e($event_information); ?>"/>
</form>

<script type="text/javascript">
    function submitForm() {
        document.forms["myForm"].submit();
    }

    submitForm();
</script>
</body>
</html>