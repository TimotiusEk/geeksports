<?php /* C:\Users\TeamO\Desktop\College\Thesis stuff\geeksports\resources\views/search_event_location.blade.php */ ?>
<html>
<head>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <?php include 'php/required_js.php'; ?>
    <?php echo $__env->make('nav_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $("#dashboard_nav_bar").show();

        document.getElementById("dashboard").className = 'active';
        document.getElementById("event_location").className = 'active';
    </script>
</head>
<body style="background-color: whitesmoke">
<div class="container">
    <div class="row">
        <form action="home">
            <div class="container">
                <div class="row">
                    <div class="col-xs-8 col-xs-offset-2">
                        <div class="input-group">
                            <input type="hidden" name="category" value="event" id="search_param">
                            <input type="text" class="form-control" name="q" placeholder="Type here . . .">
                            <span class="input-group-btn">
                    <button class="btn btn-default" type="submit" style="height: 34px"><span
                                class="glyphicon glyphicon-search"></span></button>
                </span>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="row" style="background-color: white">
        <div class="col-md-3 text-center"><img
                    style="height: 150px; width: 225px; border-radius: 10px; margin-top: 15px; padding-top: 45px; padding-left: 30px"
                    src="/images/sample_event_location_1.png"/></div>
        <div class="col-md-9" style="font-size: 40px; vertical-align: top;">
            <div style="margin-left: 70px">
                <p style="margin-top: 20px; margin-left: -30px;">
                    <b>
                        <a href="#">
                        Living World
                        </a>
                    </b>
                </p>
                <hr>
                <div style="font-size: 23px; margin-top: -10px"><img src="images/ic_location.png" style="width: 30px; margin-right: 10px; margin-bottom: 10px;">
                    Tangerang
                </div>

                <div style="font-size: 23px;">
                    <a href="#">See in Google Maps</a>
                </div>

                <div style="font-size: 23px; ">
                    <a href="#" onclick="$(this).closest('form').submit()"><img
                                src="/images/details_btn.png" width="125px" align="right"
                                style="margin-bottom: 10px"/></a>
                </div>

            </div>
        </div>
    </div>
</div>
</body>
</html>
