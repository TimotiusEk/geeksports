<?php
/**
 * Created by PhpStorm.
 * User: TeamO
 * Date: 01-Apr-19
 * Time: 1:46 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Subrole extends Model
{
    protected $fillable = ['id', 'name'];
}