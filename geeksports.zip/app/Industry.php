<?php
/**
 * Created by PhpStorm.
 * User: TeamO
 * Date: 01-Apr-19
 * Time: 2:09 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Industry extends Model
{
    protected $fillable = ['id', 'name'];
}